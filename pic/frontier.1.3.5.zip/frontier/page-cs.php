<?php // Template Name: 1 Sidebar, Right ?>

<?php get_header(); ?>

<div id="content" class="cf" role="main">
	<?php do_action( 'frontier_before_content' ); ?>

	<?php if ( is_active_sidebar( 'widgets_before_content' ) ) : ?>
		<aside id="widgets-wrap-before-content" class="cf"><?php dynamic_sidebar( 'widgets_before_content' ); ?></aside>
	<?php endif; ?>

	<?php
		the_post();
		get_template_part( 'loop', 'single' );
	?>

	<?php if ( is_active_sidebar( 'widgets_after_content' ) ) : ?>
		<aside id="widgets-wrap-after-content" class="cf"><?php dynamic_sidebar( 'widgets_after_content' ); ?></aside>
	<?php endif; ?>

	<?php do_action( 'frontier_after_content' ); ?>
</div>

<?php get_sidebar( 'right' ); ?>
<?php get_footer(); ?>