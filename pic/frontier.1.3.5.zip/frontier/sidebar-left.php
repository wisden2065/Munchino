<div id="sidebar-left" class="sidebar cf" <?php frontier_schema( 'sidebar' ); ?> role="complementary" aria-label="<?php _e( 'Sidebar Left', 'frontier' ); ?>">
	<?php do_action( 'frontier_before_sidebar_left' ); ?>
	<aside id="widgets-wrap-sidebar-left">

		<?php if ( is_active_sidebar( 'widgets_sidebar_left' ) ) : ?>
			<?php dynamic_sidebar( 'widgets_sidebar_left' ); ?>
		<?php else : ?>
			<?php
				the_widget( 'WP_Widget_Archives', 'dropdown=1', array(
					'before_widget'	=> '<section class="widget-sidebar frontier-widget widget_archive">',
					'after_widget' 	=> '</section>',
					'before_title' 	=> '<h2 class="widget-title" >',
					'after_title' 	=> '</h2>'
					) );
				the_widget( 'WP_Widget_Categories', 'dropdown=1', array(
					'before_widget'	=> '<section class="widget-sidebar frontier-widget widget_categories">',
					'after_widget' 	=> '</section>',
					'before_title' 	=> '<h2 class="widget-title" >',
					'after_title' 	=> '</h2>'
					) );
				the_widget( 'WP_Widget_Pages', 1, array(
					'before_widget'	=> '<section class="widget-sidebar frontier-widget widget_pages">',
					'after_widget' 	=> '</section>',
					'before_title' 	=> '<h2 class="widget-title" >',
					'after_title' 	=> '</h2>'
					) );
			?>
		<?php endif; ?>

	</aside>
	<?php do_action( 'frontier_after_sidebar_left' ); ?>
</div>